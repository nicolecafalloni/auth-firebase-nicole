import React, { useEffect, useState } from 'react';
import { View, Image, ScrollView, ActivityIndicator, StyleSheet, Text } from 'react-native';
import { getStorage, ref, listAll, getDownloadURL } from 'firebase/storage';
import s3 from '../awsConfig';

export default function ListarImagens({ navigation }) {
  const [images, setImages] = useState([]);
  const [loading, setLoading] = useState(true);   

  const fetchImages = async () => {
    try {
      setLoading(true);
      const storage = getStorage();
      const imagesRef = ref(storage, 'images/');
      
      const result = await listAll(imagesRef);
      
      const urls = await Promise.all(
        result.items.map(async (imageRef) => {
          const url = await getDownloadURL(imageRef);
          return {
            name: imageRef.name,
            url: url
          };
        })
      );

      setImages(urls);
    } catch (error) {
      console.error('Erro ao buscar imagens:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    
    const carregarDados = async () => {
      try{

        await s3.loadAsync([require('../assets/img-real-madrid.jpg')]);
        fetchImages();

      }catch(error){
        console.error("Erro ao carregar imagem ou buscar imagens:", error);
      }
    }

    carregarDados();
  }, []);

  return (
    <ScrollView contentContainerStyle={styles.container}>
      {loading ? (
        <ActivityIndicator size="large" color="#0000ff" />
      ) : images.length > 0 ? (
        images.map((img, index) => (
          <View key={index} style={styles.imageContainer}>
            <Image source={{ uri: img.url }} style={styles.image} />
            <Text>{img.name}</Text>
          </View>
        ))
      ) : (
        <Text>Nenhuma imagem encontrada.</Text>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 10,
    alignItems: 'center',
  },
  imageContainer: {
    marginBottom: 20,
    alignItems: 'center',
  },
  image: {
    width: 200,
    height: 200,
    resizeMode: 'cover',
  },
});
